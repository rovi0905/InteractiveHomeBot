package com.interactivehomebot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private val audioRequestCode = 5101
    private var pendingCommand: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,14,24)
        window.navigationBarColor = Color.rgb(8,14,24)
        pendingCommand = extractCommand(intent)
        buildUi()
        if (pendingCommand != null && Settings.canDrawOverlays(this)) { startBot(pendingCommand); finish() }
    }

    override fun onResume() { super.onResume(); if (::statusText.isInitialized) updateStatus() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); val c=extractCommand(intent); if(Settings.canDrawOverlays(this)){startBot(c); if(!c.isNullOrBlank()) finish()} }

    private fun buildUi() {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(36,36,36,36);setBackgroundColor(Color.rgb(8,14,24))}
        root.addView(TextView(this).apply{text="🤖  Agent";textSize=30f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}, LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{text="Floating • Voice • ChatGPT • Bixby-ready";textSize=16f;setTextColor(Color.rgb(120,220,255));gravity=Gravity.CENTER;setPadding(0,10,0,18)}, LinearLayout.LayoutParams(-1,-2))
        statusText=TextView(this).apply{textSize=15f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(0,8,0,18)}; root.addView(statusText,LinearLayout.LayoutParams(-1,-2))
        root.addView(Button(this).apply{text="Allow floating Agent";setOnClickListener{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}},LinearLayout.LayoutParams(-1,-2))
        root.addView(Button(this).apply{text="🚀 Start / Show Agent";setOnClickListener{if(Settings.canDrawOverlays(this@MainActivity))startBot("wake")else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}},LinearLayout.LayoutParams(-1,-2))
        root.addView(Button(this).apply{text="🎙️ Test voice";setOnClickListener{requestMicAndStart()}},LinearLayout.LayoutParams(-1,-2))

        val keyLabel=TextView(this).apply{text="\nChatGPT / OpenAI connection";textSize=18f;setTextColor(Color.WHITE);setPadding(0,18,0,8)}; root.addView(keyLabel)
        val key=EditText(this).apply{hint="OpenAI API key (sk-...)";setText(ChatGPTClient.getApiKey(this@MainActivity));setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);inputType=0x00000081}
        root.addView(key,LinearLayout.LayoutParams(-1,-2))
        root.addView(Button(this).apply{text="Save ChatGPT key";setOnClickListener{ChatGPTClient.saveApiKey(this@MainActivity,key.text.toString());Toast.makeText(this@MainActivity,"API key saved on this device",Toast.LENGTH_SHORT).show()}},LinearLayout.LayoutParams(-1,-2))
        val model=EditText(this).apply{hint="Model (default: gpt-5-mini)";setText(ChatGPTClient.getModel(this@MainActivity));setTextColor(Color.WHITE);setHintTextColor(Color.GRAY)}
        root.addView(model,LinearLayout.LayoutParams(-1,-2))
        root.addView(Button(this).apply{text="Save model";setOnClickListener{ChatGPTClient.saveModel(this@MainActivity,model.text.toString());Toast.makeText(this@MainActivity,"Model saved",Toast.LENGTH_SHORT).show()}},LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{text="\nTap Agent while it is floating → Agent says “How can I help?” → speak your question. Simple commands such as dance, spin, sleep and wake still work.\n\nFor ChatGPT answers, an OpenAI API key is required. The APK does not contain a shared key.";textSize=14f;setTextColor(Color.LTGRAY);setPadding(0,16,0,10)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); updateStatus()
    }
    private fun updateStatus(){statusText.text=if(Settings.canDrawOverlays(this))"● Floating permission: ON" else "○ Floating permission: OFF — allow 'Appear on top'"}
    private fun requestMicAndStart(){
        if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));return}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),audioRequestCode);return}
        startBot("voice")
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==audioRequestCode&&g.firstOrNull()==PackageManager.PERMISSION_GRANTED)startBot("voice")}
    private fun extractCommand(intent:Intent?):String?=intent?.getStringExtra(BotOverlayService.EXTRA_COMMAND)?:intent?.getStringExtra(BotOverlayService.EXTRA_TEXT)?:intent?.data?.getQueryParameter(BotOverlayService.EXTRA_COMMAND)
    private fun startBot(command:String?=null){val i=Intent(this,BotOverlayService::class.java).apply{if(!command.isNullOrBlank()){action=BotOverlayService.ACTION_COMMAND;putExtra(BotOverlayService.EXTRA_COMMAND,command)}};startForegroundService(i)}
}
