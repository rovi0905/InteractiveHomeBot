package com.interactivehomebot

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

object ChatGPTClient {
    private const val PREFS = "agent_settings"
    private const val KEY_API = "openai_api_key"
    private const val KEY_MODEL = "openai_model"
    private const val DEFAULT_MODEL = "gpt-5-mini"
    private const val ENDPOINT = "https://api.openai.com/v1/responses"
    private val executor = Executors.newCachedThreadPool()

    fun saveApiKey(context: Context, value: String) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_API, value.trim()).apply()

    fun getApiKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_API, "") ?: ""

    fun getModel(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL

    fun saveModel(context: Context, value: String) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_MODEL, value.trim()).apply()

    fun ask(context: Context, question: String, callback: (String) -> Unit) {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) { callback("Please add your OpenAI API key in Agent settings first."); return }
        executor.execute {
            val answer = try { request(apiKey, getModel(context), question) }
            catch (e: Exception) { "I couldn't reach ChatGPT: ${e.message ?: "network error"}" }
            android.os.Handler(android.os.Looper.getMainLooper()).post { callback(answer) }
        }
    }

    private fun request(apiKey: String, model: String, question: String): String {
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().apply {
            put("model", model.ifBlank { DEFAULT_MODEL })
            put("input", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", JSONArray().put(JSONObject().apply {
                    put("type", "input_text")
                    put("text", question)
                }))
            }))
        }.toString()
        conn.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            throw IllegalStateException(msg ?: "HTTP $code")
        }
        val json = JSONObject(text)
        val direct = json.optString("output_text", "")
        if (direct.isNotBlank()) return direct.trim()
        val output = json.optJSONArray("output") ?: return "I received an empty answer."
        val parts = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text", "")
                if (t.isNotBlank()) parts.append(t).append("\n")
            }
        }
        return parts.toString().trim().ifBlank { "I couldn't find a text answer." }
    }
}
