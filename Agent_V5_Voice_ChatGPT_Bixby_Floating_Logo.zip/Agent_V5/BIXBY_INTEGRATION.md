# InteractiveHomeBot V4 — Bixby / Automation command interface

InteractiveHomeBot V4 exposes an Android command entry point that can be called by a Bixby/Automation flow or another automation app.

## Deep-link format

`interactivehomebot://command?command=dance`

Replace `dance` with a supported command.

## Supported commands

- `hello`
- `dance`
- `explore`
- `walk`
- `roam`
- `spin`
- `jump`
- `happy`
- `sad`
- `sleep`
- `wake`
- `hide`
- `stop`

Natural-language text also works because the app normalizes phrases. For example, `make the bot dance` is treated as `dance`.

## Example Android intent

```text
ACTION_VIEW
interactivehomebot://command?command=dance
```

The app receives the command, starts the floating foreground service when overlay permission has been granted, and forwards the action to the visible bot.

## Voice control

V4 includes a microphone button in the app. Tap **Tap to talk**, speak a command, and the recognized text is sent to the same command interface.

This is tap-to-talk rather than an always-listening microphone. The app therefore does not need to keep the microphone active while the bot is floating.

## Important Bixby note

The Android app provides the command endpoint; a native Bixby/Automation capsule or flow still needs to be configured in Samsung's Bixby/Automation developer tooling. The APK alone does not automatically publish a new Bixby capsule.
