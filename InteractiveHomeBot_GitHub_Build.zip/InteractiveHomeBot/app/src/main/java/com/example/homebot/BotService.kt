package com.example.homebot

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import kotlin.math.*
import kotlin.random.Random

class BotService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bot: BotView
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var targetX = 30
    private var targetY = 180
    private var moving = false
    private var sleeping = false
    private var lastInteraction = System.currentTimeMillis()
    private var waveUntil = 0L

    private val sleepCheck = object : Runnable {
        override fun run() {
            if (::bot.isInitialized) {
                val idle = System.currentTimeMillis() - lastInteraction
                if (!sleeping && idle > 30000L) {
                    sleeping = true
                    moving = false
                    bot.setSleeping(true)
                }
            }
            handler.postDelayed(this, 5000)
        }
    }

    fun onBotInteraction() {
        lastInteraction = System.currentTimeMillis()
        if (sleeping) {
            sleeping = false
            bot.setSleeping(false)
        }
        waveUntil = System.currentTimeMillis() + 1800L
        bot.setWaving(true)
    }

    private val moveTick = object : Runnable {
        override fun run() {
            if (!::bot.isInitialized) return
            if (sleeping) {
                handler.postDelayed(this, 1000)
                return
            }
            val size = Point()
            wm.defaultDisplay.getRealSize(size)

            val maxX = max(10, size.x - params.width - 12)
            val maxY = max(101, size.y - params.height - 90)

            if (!moving || (abs(params.x - targetX) < 6 && abs(params.y - targetY) < 6)) {
                targetX = Random.nextInt(10, maxX)
                targetY = Random.nextInt(100, maxY)
                moving = true
                bot.setMoving(true)
            }

            val dx = targetX - params.x
            val dy = targetY - params.y
            params.x += (dx * 0.035f).roundToInt().coerceIn(-12, 12)
            params.y += (dy * 0.035f).roundToInt().coerceIn(-12, 12)
            wm.updateViewLayout(bot, params)

            if (abs(dx) < 8 && abs(dy) < 8) {
                moving = false
                bot.setMoving(false)
                handler.postDelayed(this, Random.nextLong(900, 2400))
            } else {
                handler.postDelayed(this, 35)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channelId = "bot"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "Home Bot", NotificationManager.IMPORTANCE_LOW)
            )
        }
        startForeground(
            7,
            Notification.Builder(this, channelId)
                .setContentTitle("Home Bot")
                .setContentText("Your animated assistant is roaming around")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        )

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bot = BotView(this)
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            220, 280, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 30
        params.y = 180

        wm.addView(bot, params)
        bot.setInteractionCallback { onBotInteraction() }
        handler.postDelayed(moveTick, 1200)
        handler.post(sleepCheck)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::bot.isInitialized) wm.removeView(bot)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class BotView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var sleeping = false
    private var waving = false
    private var moving = false
    private var callback: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            t += if (moving) .18f else .10f
            invalidate()
            handler.postDelayed(this, 40)
        }
    }

    init {
        isClickable = true
        handler.post(tick)
    }

    fun setInteractionCallback(cb: () -> Unit) {
        callback = cb
    }

    fun setMoving(value: Boolean) {
        moving = value
        invalidate()
    }

    fun setSleeping(value: Boolean) {
        sleeping = value
        invalidate()
    }

    fun setWaving(value: Boolean) {
        waving = value
        invalidate()
        if (value) {
            handler.postDelayed({
                waving = false
                invalidate()
            }, 1800)
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val bob = if (sleeping) 0f else sin(t.toDouble()).toFloat() * if (moving) 13f else 7f
        val cy = 145f + bob

        p.color = Color.argb(238, 12, 22, 40)
        c.drawRoundRect(8f, 8f, width - 8f, 92f, 22f, 22f, p)
        p.color = Color.WHITE
        p.textSize = 18f

        val title = when {
            sleeping -> "Zzz… 😴"
            waving -> "Hi again! 👋"
            moving -> "I'm exploring! 🤖"
            else -> "Hey! Tap me 👋"
        }
        c.drawText(title, 20f, 45f, p)

        p.textSize = 13f
        val subtitle = when {
            sleeping -> "Wake me with a tap"
            waving -> "I'm happy you're here"
            moving -> "I move around on my own"
            else -> "Your little home assistant"
        }
        c.drawText(subtitle, 20f, 70f, p)

        // Body
        p.color = Color.rgb(235, 245, 255)
        c.drawRoundRect(cx - 58, cy - 48, cx + 58, cy + 75, 42f, 42f, p)
        p.color = Color.rgb(8, 18, 35)
        c.drawRoundRect(cx - 45, cy - 28, cx + 45, cy + 38, 28f, 28f, p)

        // Face
        p.color = Color.rgb(80, 190, 255)
        if (sleeping) {
            p.strokeWidth = 5f
            p.style = Paint.Style.STROKE
            c.drawLine(cx - 28, cy + 2, cx - 13, cy + 2, p)
            c.drawLine(cx + 13, cy + 2, cx + 28, cy + 2, p)
            p.style = Paint.Style.FILL
        } else {
            c.drawOval(cx - 29, cy - 3, cx - 12, cy + 8, p)
            c.drawOval(cx + 12, cy - 3, cx + 29, cy + 8, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f
            c.drawArc(cx - 14, cy + 4, cx + 14, cy + 24, 15f, 150f, false, p)
            p.style = Paint.Style.FILL
        }

        // Waving hand
        if (waving) {
            val angle = sin(t.toDouble() * 2.5).toFloat() * 18f
            c.save()
            c.rotate(angle, cx + 60f, cy + 5f)
            p.color = Color.rgb(235, 245, 255)
            c.drawCircle(cx + 68f, cy + 2f, 17f, p)
            c.restore()
        }

        // Heart/core
        p.color = Color.rgb(80, 190, 255)
        c.drawCircle(cx, cy + 62, 15f, p)
        p.color = Color.WHITE
        p.textSize = 16f
        c.drawText("♥", cx - 6, cy + 68, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            callback?.invoke()
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
