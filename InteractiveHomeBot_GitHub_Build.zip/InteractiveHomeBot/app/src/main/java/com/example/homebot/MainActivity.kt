package com.example.homebot

import android.app.*
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = Button(this).apply {
            text = "Enable my roaming Home Bot"
            textSize = 18f
            setPadding(30,30,30,30)
            setOnClickListener { enableBot() }
        }
        setContentView(b)
        if (Settings.canDrawOverlays(this)) startBot()
    }
    private fun enableBot() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        } else startBot()
    }
    private fun startBot() {
        val i = Intent(this, BotService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Bot is now on your screen", Toast.LENGTH_SHORT).show()
    }
}
