# Agent v6 — Floating ChatGPT Companion

Agent is a premium floating Android companion. Tap the Agent itself to start voice input; there is no separate microphone popup.

Features:
- Floating interactive Agent overlay
- Tap Agent to speak
- Speech recognition retry logic
- Spoken ChatGPT responses
- OpenAI Responses API with web search enabled for current or uncertain questions
- Autonomous movement and thinking/listening/speaking animations
- Random space facts and jokes
- Premium dark UI
- ChatGPT-only integration

OpenAI API keys are entered by the user on the device. Do not commit API keys to the repository.
