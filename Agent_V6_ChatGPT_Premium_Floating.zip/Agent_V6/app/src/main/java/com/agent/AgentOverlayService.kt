package com.agent

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.speech.*
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.view.WindowManager
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

class AgentOverlayService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_COMMAND = "com.agent.COMMAND"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "agent_overlay"
        private const val NOTIFICATION_ID = 2101
    }

    private lateinit var windowManager: WindowManager
    private var agentView: FloatingAgentView? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var retryVoice = false
    private var voicePrompt = ""
    private var destroyed = false

    private val spontaneous = arrayOf(
        "Space fact: a day on Venus is longer than its year. Cosmic scheduling is complicated.",
        "Space fact: Saturn would float in water if you had a bathtub big enough. Please don't try this.",
        "Joke: Why did the astronaut break up with the moon? It needed more space.",
        "Space fact: neutron stars can spin hundreds of times every second. That's one serious workout.",
        "Joke: I told a black hole a joke. It sucked.",
        "Space fact: there are more stars in the observable universe than grains of sand on many Earth beaches."
    )

    private val spontaneousRunnable = object : Runnable {
        override fun run() {
            if (!destroyed && agentView != null) {
                val item = spontaneous[Random.nextInt(spontaneous.size)]
                agentView?.showMessage(item)
                speak(item)
            }
            handler.postDelayed(this, Random.nextLong(45_000L, 90_001L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
        tts = TextToSpeech(this, this)
        showOverlay()
        handler.postDelayed(spontaneousRunnable, Random.nextLong(30_000L, 60_001L))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra(EXTRA_COMMAND)
            ?: intent?.getStringExtra(EXTRA_TEXT)
        if (!command.isNullOrBlank()) {
            if (command.equals("voice", true)) startVoiceInteraction()
            else agentView?.command(normalizeCommand(command))
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun normalizeCommand(raw: String): String = when {
        "dance" in raw.lowercase() -> "dance"
        "spin" in raw.lowercase() || "turn" in raw.lowercase() -> "spin"
        "jump" in raw.lowercase() -> "jump"
        "happy" in raw.lowercase() -> "happy"
        "sad" in raw.lowercase() -> "sad"
        "sleep" in raw.lowercase() -> "sleep"
        "wake" in raw.lowercase() || "awake" in raw.lowercase() -> "wake"
        "explore" in raw.lowercase() || "walk" in raw.lowercase() || "roam" in raw.lowercase() || "move" in raw.lowercase() -> "explore"
        "stop" in raw.lowercase() || "hide" in raw.lowercase() -> "hide"
        "hello" in raw.lowercase() || "hi" in raw.lowercase() || "hey" in raw.lowercase() -> "hello"
        else -> "hello"
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(): Notification {
        val launch = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Agent")
            .setContentText("Agent is floating and ready")
            .setOngoing(true)
            .setContentIntent(pending)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the floating Agent responsive."
                }
            )
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        agentView = FloatingAgentView(this)
        val size = dp(210)
        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18); y = dp(175)
        }
        try { windowManager.addView(agentView, params) }
        catch (_: Exception) { agentView = null; stopSelf() }
    }

    fun startVoiceInteraction() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            agentView?.setState("error")
            agentView?.showMessage("Microphone permission is needed.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            agentView?.setState("error")
            agentView?.showMessage("Speech recognition isn't available on this phone.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        retryVoice = false
        voicePrompt = "How can I help?"
        agentView?.setState("listening")
        agentView?.showMessage("Listening…")
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { agentView?.setState("listening") }
            override fun onBeginningOfSpeech() { agentView?.showMessage("I'm listening…") }
            override fun onRmsChanged(rmsdB: Float) { agentView?.setAudioLevel(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { agentView?.setState("thinking"); agentView?.showMessage("Thinking…") }
            override fun onError(error: Int) {
                if (!retryVoice && error in setOf(
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT
                    )) {
                    retryVoice = true
                    handler.postDelayed({ if (!destroyed) startVoiceInteraction() }, 350)
                } else {
                    agentView?.setState("idle")
                    agentView?.showMessage("I didn't catch that. Tap me and try again.")
                }
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.maxByOrNull { it.length }?.trim()
                if (text.isNullOrBlank()) {
                    agentView?.setState("idle")
                    agentView?.showMessage("I didn't catch that. Tap me and try again.")
                    return
                }
                handleUserText(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val ri = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100)
            putExtra(RecognizerIntent.EXTRA_PROMPT, voicePrompt)
        }
        try { speechRecognizer?.startListening(ri) }
        catch (_: Exception) {
            agentView?.setState("error")
            agentView?.showMessage("I couldn't start voice input. Tap me to retry.")
        }
    }

    private fun handleUserText(text: String) {
        val local = normalizeCommandOrNull(text)
        if (local != null) {
            agentView?.command(local)
            if (local == "hello") speak("Hello. What can I do for you?")
            return
        }
        agentView?.setState("thinking")
        agentView?.showMessage("Thinking with ChatGPT…")
        ChatGPTClient.ask(this, text) { answer ->
            if (destroyed) return@ask
            agentView?.setState("speaking")
            agentView?.showMessage(answer)
            speak(answer)
            handler.postDelayed({ agentView?.setState("idle") }, 1200)
        }
    }

    private fun normalizeCommandOrNull(raw: String): String? {
        val c = raw.lowercase()
        return when {
            "dance" in c -> "dance"
            "spin" in c || "turn around" in c -> "spin"
            "jump" in c -> "jump"
            "happy" in c -> "happy"
            "sad" in c -> "sad"
            "sleep" in c -> "sleep"
            "wake" in c || "awake" in c -> "wake"
            "explore" in c || "walk around" in c || "roam" in c -> "explore"
            "hide" in c || "go away" in c -> "hide"
            "hello" in c || "hi " in c || c == "hey" -> "hello"
            else -> null
        }
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        tts?.speak(text.replace(Regex("\\s+"), " ").take(1200), TextToSpeech.QUEUE_FLUSH, null, "agent_response")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        agentView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        agentView = null
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FloatingAgentView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans", Typeface.BOLD) }
        private var phase = 0f
        private var state = "idle"
        private var message = ""
        private var messageUntil = 0L
        private var sleeping = false
        private var specialState = ""
        private var specialUntil = 0L
        private var lastTap = 0L
        private var targetX = .50f; private var targetY = .55f
        private var agentX = .50f; private var agentY = .55f
        private var lastMove = 0L
        private var downRawX = 0f; private var downRawY = 0f; private var moved = false
        private var audioLevel = 0f

        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); chooseTarget() }

        fun setState(s: String) { state = s; invalidate() }
        fun setAudioLevel(v: Float) { audioLevel = ((v + 2f) / 15f).coerceIn(0f, 1f); invalidate() }
        fun showMessage(t: String) { message = t; messageUntil = System.currentTimeMillis() + 5200; invalidate() }

        fun command(action: String) {
            val now = System.currentTimeMillis()
            sleeping = false
            when (action) {
                "dance" -> { specialState="dance"; specialUntil=now+4000; message="Let's dance! ✨" }
                "spin" -> { specialState="spin"; specialUntil=now+1800; message="Spin mode!" }
                "jump" -> { specialState="jump"; specialUntil=now+1600; message="Boing! 🚀" }
                "happy" -> { specialState="happy"; specialUntil=now+2600; message="I'm happy! ✦" }
                "sad" -> { specialState="sad"; specialUntil=now+2600; message="A little sad…" }
                "sleep" -> { sleeping=true; specialState=""; specialUntil=0; message="Zzz…" }
                "wake" -> { message="I'm awake! ✨" }
                "explore" -> { chooseTarget(); message="Exploring… 👀" }
                "hide" -> { (context as? AgentOverlayService)?.stopSelf(); return }
                else -> message="Hello! ✨"
            }
            state="idle"; messageUntil=now+3000; invalidate()
        }

        private fun chooseTarget() {
            targetX=Random.nextFloat().coerceIn(.25f,.75f)
            targetY=Random.nextFloat().coerceIn(.35f,.72f)
            lastMove=System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            val w=width.toFloat(); val h=height.toFloat()
            phase += .055f
            val now=System.currentTimeMillis()
            if (!sleeping) {
                val dx=targetX-agentX; val dy=targetY-agentY
                val d=sqrt(dx*dx+dy*dy)
                if(d>.008f){agentX+=dx*.010f; agentY+=dy*.010f}
                else if(now-lastMove>1800) chooseTarget()
            }
            val pulse = 1f + sin(phase*2f)*.025f
            val bob = if(sleeping) 0f else sin(phase*2f)*.012f
            val danceX = if(specialState=="dance" && now<specialUntil) cos(phase*5f)*.035f else 0f
            val cx=(agentX+danceX)*w; val cy=(agentY+bob)*h
            drawAgent(canvas,cx,cy,w,h,pulse)
            if(now<messageUntil) drawBubble(canvas,message,w,h)
            postInvalidateOnAnimation()
        }

        private fun drawAgent(c:Canvas,cx:Float,cy:Float,w:Float,h:Float,pulse:Float) {
            val now=System.currentTimeMillis()
            val thinking=state=="thinking"
            val listening=state=="listening"
            val speaking=state=="speaking"
            val scale=(w.coerceAtMost(h)*.29f).coerceIn(50f,82f)*pulse
            c.save()
            if(specialState=="spin" && now<specialUntil) c.rotate(sin(phase*8f)*18f,cx,cy)
            // premium glow
            paint.style=Paint.Style.FILL
            paint.shader=RadialGradient(cx,cy,scale*1.45f,intArrayOf(Color.argb(70,70,210,255),Color.argb(25,110,80,255),Color.TRANSPARENT),floatArrayOf(0f,.55f,1f),Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,scale*1.45f,paint); paint.shader=null
            // shadow
            paint.color=Color.argb(85,0,0,0)
            c.drawOval(cx-scale*.70f,cy+scale*.70f,cx+scale*.70f,cy+scale*.90f,paint)
            // antenna
            paint.strokeWidth=scale*.055f; paint.strokeCap=Paint.Cap.ROUND; paint.color=Color.rgb(185,225,245)
            c.drawLine(cx,cy-scale*.60f,cx,cy-scale*.95f,paint)
            paint.color=Color.rgb(100,235,255); c.drawCircle(cx,cy-scale*.99f,scale*.095f,paint)
            // body shell
            paint.shader=LinearGradient(cx-scale,cy-scale,cx+scale,cy+scale,Color.rgb(245,250,255),Color.rgb(95,135,170),Shader.TileMode.CLAMP)
            c.drawRoundRect(cx-scale*.72f,cy-scale*.58f,cx+scale*.72f,cy+scale*.58f,scale*.22f,scale*.22f,paint)
            paint.shader=null
            // visor
            paint.color=Color.rgb(7,17,29)
            c.drawRoundRect(cx-scale*.58f,cy-scale*.37f,cx+scale*.58f,cy+scale*.24f,scale*.16f,scale*.16f,paint)
            paint.style=Paint.Style.STROKE; paint.strokeWidth=scale*.035f
            paint.color=Color.argb(190,100,235,255)
            c.drawRoundRect(cx-scale*.58f,cy-scale*.37f,cx+scale*.58f,cy+scale*.24f,scale*.16f,scale*.16f,paint)
            paint.style=Paint.Style.FILL
            // eyes
            val eyeGlow=if(listening) Color.rgb(255,215,100) else Color.rgb(100,240,255)
            paint.color=eyeGlow
            val eyeR=if(listening) scale*.09f+audioLevel*scale*.05f else scale*.075f
            c.drawCircle(cx-scale*.23f,cy-scale*.08f,eyeR,paint); c.drawCircle(cx+scale*.23f,cy-scale*.08f,eyeR,paint)
            // state ring
            if(thinking || speaking || listening){
                paint.style=Paint.Style.STROKE
                paint.strokeWidth=scale*.045f
                paint.color=if(listening) Color.rgb(255,215,100) else Color.rgb(130,110,255)
                val r=scale*(.78f+sin(phase*3f)*.04f)
                c.drawArc(cx-r,cy-r,cx+r,cy+r,phase*50f,240f,false,paint)
                paint.style=Paint.Style.FILL
            }
            // arms
            paint.strokeWidth=scale*.11f; paint.color=Color.rgb(125,165,195)
            val wave=now-lastTap<700 || specialState=="dance"
            c.drawLine(cx-scale*.72f,cy,cx-scale*(if(wave).98f else .86f),cy+scale*(if(wave)-.38f else .18f),paint)
            c.drawLine(cx+scale*.72f,cy,cx+scale*(if(wave).98f else .86f),cy+scale*(if(wave)-.38f else .18f),paint)
            // heart/status core
            paint.color=Color.rgb(90,210,255)
            c.drawCircle(cx,cy+scale*.40f,scale*.08f,paint)
            textPaint.textSize=scale*.17f; textPaint.color=Color.WHITE; textPaint.textAlign=Paint.Align.CENTER
            c.drawText("AGENT",cx,cy+scale*.72f,textPaint)
            if(thinking){
                textPaint.textSize=scale*.22f
                val dots=(now/350)%4
                c.drawText("•".repeat(dots.toInt()+1),cx,cy-scale*1.18f,textPaint)
            }
            c.restore()
        }

        private fun drawBubble(c:Canvas,text:String,w:Float,h:Float){
            paint.style=Paint.Style.FILL
            paint.shader=LinearGradient(0f,0f,0f,h*.22f,Color.argb(245,255,255,255),Color.argb(235,225,240,250),Shader.TileMode.CLAMP)
            val rect=RectF(w*.025f,h*.015f,w*.975f,h*.27f)
            c.drawRoundRect(rect,24f,24f,paint); paint.shader=null
            textPaint.textSize=(w*.065f).coerceIn(12f,17f); textPaint.color=Color.rgb(15,30,45); textPaint.textAlign=Paint.Align.CENTER
            val clean=if(text.length>90) text.take(87)+"…" else text
            c.drawText(clean,w/2f,h*.16f,textPaint)
        }

        override fun onTouchEvent(e:MotionEvent):Boolean{
            when(e.actionMasked){
                MotionEvent.ACTION_DOWN->{downRawX=e.rawX;downRawY=e.rawY;moved=false;return true}
                MotionEvent.ACTION_MOVE->{
                    if(abs(e.rawX-downRawX)>12||abs(e.rawY-downRawY)>12)moved=true
                    if(moved){
                        val service=context as AgentOverlayService
                        val p=layoutParams as WindowManager.LayoutParams
                        p.x=(p.x+(e.rawX-downRawX)).toInt(); p.y=(p.y+(e.rawY-downRawY)).toInt()
                        downRawX=e.rawX;downRawY=e.rawY
                        service.windowManager.updateViewLayout(this,p)
                    }; return true
                }
                MotionEvent.ACTION_UP->{
                    if(!moved){
                        lastTap=System.currentTimeMillis()
                        state="listening"; showMessage("Listening…")
                        (context as AgentOverlayService).startVoiceInteraction()
                    }; return true
                }
            }; return true
        }
    }
}
