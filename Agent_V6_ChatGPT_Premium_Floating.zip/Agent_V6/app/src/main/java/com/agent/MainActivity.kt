package com.agent

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private val audioRequestCode = 5101
    private var pendingStart = false

    private fun bg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(7,12,25), Color.rgb(18,22,48), Color.rgb(7,13,27))
    ).apply { cornerRadius = 42f }

    private fun cardBg(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(235,28,38,62), Color.argb(220,15,24,45))
    ).apply { cornerRadius = 30f; setStroke(1, Color.argb(90,110,220,255)) }

    private fun actionButton(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(34,78,115), Color.rgb(73,51,132))
            ).apply { cornerRadius = 24f }
            setPadding(24, 8, 24, 8)
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7,12,25)
        window.navigationBarColor = Color.rgb(7,12,25)
        buildUi()
    }

    override fun onResume() { super.onResume(); if (::statusText.isInitialized) updateStatus() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 26, 28, 24)
            background = bg()
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7,12,25)) }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "✦  AGENT"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 2)
        })
        root.addView(TextView(this).apply {
            text = "Your floating ChatGPT companion"
            textSize = 16f
            setTextColor(Color.rgb(130,225,255))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        })

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 18, 22, 18)
        }
        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        statusCard.addView(statusText)
        root.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,14) })

        val launchCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 20, 22, 20)
        }
        launchCard.addView(TextView(this).apply {
            text = "FLOATING AGENT"
            textSize = 13f
            setTextColor(Color.rgb(110,235,255))
        })
        launchCard.addView(TextView(this).apply {
            text = "Tap the Agent itself to talk."
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        })
        launchCard.addView(TextView(this).apply {
            text = "The microphone is built into the Agent. No separate mic popup."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 14)
        })
        launchCard.addView(actionButton("✦  Start / Show Agent") { ensurePermissionsAndStart() },
            LinearLayout.LayoutParams(-1, 54))
        root.addView(launchCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,14) })

        val aiCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 20, 22, 20)
        }
        aiCard.addView(TextView(this).apply {
            text = "CHATGPT INTELLIGENCE"
            textSize = 13f
            setTextColor(Color.rgb(110,235,255))
        })
        aiCard.addView(TextView(this).apply {
            text = "ChatGPT + online search"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0,8,0,4)
        })
        aiCard.addView(TextView(this).apply {
            text = "Agent can use OpenAI's web-search tool when a question needs current or missing information."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0,0,0,14)
        })
        val key = EditText(this).apply {
            hint = "OpenAI API key"
            setText(ChatGPTClient.getApiKey(this@MainActivity))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = 0x00000081
            setSingleLine(true)
            background = GradientDrawable().apply {
                setColor(Color.argb(90,0,0,0)); cornerRadius=20f
                setStroke(1,Color.argb(70,130,220,255))
            }
            setPadding(20,0,20,0)
        }
        aiCard.addView(key, LinearLayout.LayoutParams(-1,54))
        aiCard.addView(actionButton("Save OpenAI key") {
            ChatGPTClient.saveApiKey(this@MainActivity, key.text.toString())
            Toast.makeText(this@MainActivity, "OpenAI key saved on this device", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1,54).apply { topMargin=10 })
        root.addView(aiCard, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,14) })

        val personality = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22,20,22,20)
        }
        personality.addView(TextView(this).apply {
            text="AGENT PERSONALITY"
            textSize=13f; setTextColor(Color.rgb(110,235,255))
        })
        personality.addView(TextView(this).apply {
            text="Always moving • Thinking • Curious"
            textSize=18f; setTextColor(Color.WHITE)
            typeface=android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0,8,0,4)
        })
        personality.addView(TextView(this).apply {
            text="Agent wanders around, shows thinking/listening animations, and occasionally shares a space fact or joke."
            textSize=14f; setTextColor(Color.LTGRAY)
        })
        root.addView(personality, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,20) })

        root.addView(TextView(this).apply {
            text="Agent • ChatGPT powered"
            textSize=12f; setTextColor(Color.rgb(105,125,150)); gravity=Gravity.CENTER
            setPadding(0,8,0,12)
        })

        setContentView(scroll)
        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = if (Settings.canDrawOverlays(this))
            "●  Floating permission ON   •   Voice ready when you tap Agent"
        else
            "○  Allow “Appear on top” to place Agent over your home screen"
    }

    private fun ensurePermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingStart = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequestCode)
            return
        }
        startAgent()
    }

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r == audioRequestCode && g.firstOrNull() == PackageManager.PERMISSION_GRANTED && pendingStart) {
            pendingStart=false
            startAgent()
        }
    }

    private fun startAgent() {
        startForegroundService(Intent(this, AgentOverlayService::class.java))
        Toast.makeText(this, "Agent is floating. Tap Agent to speak.", Toast.LENGTH_SHORT).show()
    }
}
