package com.interactivehomebot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var statusText: TextView
    private lateinit var voiceButton: Button
    private var pendingCommand: String? = null
    private val audioRequestCode = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 24)
        window.navigationBarColor = Color.rgb(8, 14, 24)

        pendingCommand = extractCommand(intent)
        buildUi()

        if (pendingCommand != null && Settings.canDrawOverlays(this)) {
            startBot(pendingCommand)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        updateOverlayStatus()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val command = extractCommand(intent)
        if (Settings.canDrawOverlays(this)) {
            startBot(command)
            if (!command.isNullOrBlank()) finish()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 42, 42, 42)
            setBackgroundColor(Color.rgb(8, 14, 24))
        }

        val title = TextView(this).apply {
            text = "🤖  Agent"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val subtitle = TextView(this).apply {
            text = "Floating • Interactive • Voice • Bixby-ready"
            textSize = 16f
            setTextColor(Color.rgb(120, 220, 255))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))

        statusText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 22)
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))

        val overlayButton = Button(this).apply {
            text = "Allow floating bot"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        root.addView(overlayButton, LinearLayout.LayoutParams(-1, -2))

        val startButton = Button(this).apply {
            text = "🚀 Start / Show Bot"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startBot("wake")
                    Toast.makeText(this@MainActivity, "Bot started", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, -2))

        voiceButton = Button(this).apply {
            text = "🎙️ Tap to talk"
            setOnClickListener { beginVoiceCommand() }
        }
        root.addView(voiceButton, LinearLayout.LayoutParams(-1, -2))

        val help = TextView(this).apply {
            text = "\nSay commands such as:\n• hello / hi\n• dance\n• explore / walk / roam\n• jump / spin\n• happy / sad\n• sleep / wake\n• hide / stop\n\nTip: Agent uses tap-to-talk instead of an always-listening microphone, which is friendlier to battery and privacy.\n\nBixby-ready deep link:\ninteractivehomebot://command?command=dance"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 10)
        }

        val scroll = ScrollView(this).apply { addView(help) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        updateOverlayStatus()
    }

    private fun updateOverlayStatus() {
        if (!::statusText.isInitialized) return
        statusText.text = if (Settings.canDrawOverlays(this)) {
            "● Floating permission: ON\nYour bot can appear over Home and other apps."
        } else {
            "○ Floating permission: OFF\nAllow 'Appear on top' to start the bot."
        }
    }

    private fun beginVoiceCommand() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Appear on top' first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "No speech recognition service is available", Toast.LENGTH_LONG).show()
            return
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequestCode)
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                voiceButton.text = "🔴 Listening… speak now"
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { voiceButton.text = "⏳ Processing…" }
            override fun onError(error: Int) {
                voiceButton.text = "🎙️ Tap to talk"
                Toast.makeText(this@MainActivity, speechError(error), Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                voiceButton.text = "🎙️ Tap to talk"
                if (!text.isNullOrBlank()) {
                    statusText.text = "Heard: \"$text\"\nSending command to your bot…"
                    startBot(text)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say: dance, explore, sleep, wake, or hello")
        }
        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun speechError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Microphone error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service network error"
        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy"
        else -> "Voice command failed ($error)"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            beginVoiceCommand()
        } else if (requestCode == audioRequestCode) {
            Toast.makeText(this, "Microphone permission is needed for voice commands", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractCommand(intent: Intent?): String? {
        return intent?.getStringExtra(BotOverlayService.EXTRA_COMMAND)
            ?: intent?.getStringExtra(BotOverlayService.EXTRA_TEXT)
            ?: intent?.data?.getQueryParameter(BotOverlayService.EXTRA_COMMAND)
    }

    private fun startBot(command: String? = null) {
        val serviceIntent = Intent(this, BotOverlayService::class.java).apply {
            if (!command.isNullOrBlank()) {
                action = BotOverlayService.ACTION_COMMAND
                putExtra(BotOverlayService.EXTRA_COMMAND, command)
            }
        }
        startForegroundService(serviceIntent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}
