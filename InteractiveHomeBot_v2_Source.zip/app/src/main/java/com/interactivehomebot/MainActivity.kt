package com.interactivehomebot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.MotionEvent
import android.view.View
import android.view.Window
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var botView: BotView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.rgb(16, 24, 32))
        window.setNavigationBarColor(Color.rgb(16, 24, 32))
        botView = BotView()
        setContentView(botView)
        handleCommand(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCommand(intent)
    }

    private fun handleCommand(intent: Intent?) {
        val command = intent?.getStringExtra("command")
            ?: intent?.getStringExtra("text")
            ?: intent?.data?.getQueryParameter("command")
            ?: return

        val c = command.lowercase()
        when {
            "dance" in c -> botView.command("dance")
            "sleep" in c -> botView.command("sleep")
            "wake" in c -> botView.command("wake")
            "hello" in c || "hi" in c -> botView.command("hello")
            "explore" in c || "walk" in c -> botView.command("explore")
            else -> botView.command("hello")
        }
    }

    private inner class BotView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans", Typeface.BOLD)
        }
        private var botX = 0.5f
        private var botY = 0.55f
        private var targetX = 0.5f
        private var targetY = 0.55f
        private var phase = 0f
        private var blink = 0f
        private var state = "idle"
        private var message = "Hi! Tap me 👋"
        private var messageUntil = 0L
        private var sleeping = false
        private var danceUntil = 0L
        private var lastTap = 0L
        private var lastMove = 0L

        init {
            setBackgroundColor(Color.rgb(16, 24, 32))
            chooseTarget()
            postInvalidateOnAnimation()
        }

        fun command(action: String) {
            val now = System.currentTimeMillis()
            when (action) {
                "dance" -> {
                    sleeping = false
                    danceUntil = now + 3500
                    message = "Let's dance! 🎵"
                }
                "sleep" -> {
                    sleeping = true
                    message = "Zzz... 😴"
                }
                "wake" -> {
                    sleeping = false
                    message = "I'm awake! ✨"
                }
                "explore" -> {
                    sleeping = false
                    chooseTarget()
                    message = "Exploring the room..."
                }
                else -> {
                    sleeping = false
                    message = "Hello! 🤖"
                }
            }
            messageUntil = now + 2500
            invalidate()
        }

        private fun chooseTarget() {
            targetX = Random.nextFloat().coerceIn(0.18f, 0.82f)
            targetY = Random.nextFloat().coerceIn(0.38f, 0.70f)
            lastMove = System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            phase += 0.055f

            // Soft floor glow
            paint.color = Color.rgb(28, 45, 58)
            canvas.drawOval(
                w * 0.12f, h * 0.77f, w * 0.88f, h * 0.92f, paint
            )

            if (!sleeping) {
                val dx = targetX - botX
                val dy = targetY - botY
                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                if (distance > 0.008f) {
                    botX += dx * 0.012f
                    botY += dy * 0.012f
                } else if (System.currentTimeMillis() - lastMove > 1800) {
                    chooseTarget()
                }
            }

            val dance = System.currentTimeMillis() < danceUntil
            val bob = if (sleeping) 0f else sin(phase * 2f) * 0.012f
            val danceX = if (dance) cos(phase * 5f) * 0.035f else 0f
            val cx = (botX + danceX) * w
            val cy = (botY + bob) * h

            drawBot(canvas, cx, cy, w, h, dance)

            val now = System.currentTimeMillis()
            if (now < messageUntil) {
                drawBubble(canvas, message, w, h)
            } else if (now % 9000 < 80 && !sleeping) {
                message = listOf(
                    "I'm exploring 👀",
                    "Tap me!",
                    "Everything looks good.",
                    "Where should I go?",
                    "🤖 Beep boop!"
                ).random()
                messageUntil = now + 2400
            }

            postInvalidateOnAnimation()
        }

        private fun drawBot(canvas: Canvas, cx: Float, cy: Float, w: Float, h: Float, dance: Boolean) {
            val scale = (w.coerceAtMost(h) * 0.22f).coerceIn(90f, 190f)
            val bodyTop = cy - scale * 0.55f
            val bodyBottom = cy + scale * 0.55f

            // Shadow
            paint.color = Color.argb(90, 0, 0, 0)
            canvas.drawOval(cx - scale * 0.62f, bodyBottom + scale * 0.25f,
                cx + scale * 0.62f, bodyBottom + scale * 0.48f, paint)

            // Antenna
            paint.strokeWidth = scale * 0.055f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(180, 220, 235)
            canvas.drawLine(cx, bodyTop, cx, bodyTop - scale * 0.35f, paint)
            paint.color = Color.rgb(90, 220, 255)
            canvas.drawCircle(cx, bodyTop - scale * 0.40f, scale * 0.09f, paint)

            // Body
            paint.color = Color.rgb(80, 120, 145)
            canvas.drawRoundRect(
                cx - scale * 0.65f, bodyTop,
                cx + scale * 0.65f, bodyBottom,
                scale * 0.22f, scale * 0.22f, paint
            )

            // Face
            paint.color = Color.rgb(12, 22, 30)
            canvas.drawRoundRect(
                cx - scale * 0.52f, bodyTop + scale * 0.16f,
                cx + scale * 0.52f, bodyTop + scale * 0.62f,
                scale * 0.15f, scale * 0.15f, paint
            )

            val blinking = ((System.currentTimeMillis() / 1000) % 5 == 0L)
            paint.color = Color.rgb(100, 235, 255)
            if (sleeping || blinking) {
                paint.strokeWidth = scale * 0.045f
                canvas.drawLine(cx - scale * 0.31f, bodyTop + scale * 0.39f,
                    cx - scale * 0.12f, bodyTop + scale * 0.39f, paint)
                canvas.drawLine(cx + scale * 0.12f, bodyTop + scale * 0.39f,
                    cx + scale * 0.31f, bodyTop + scale * 0.39f, paint)
            } else {
                canvas.drawCircle(cx - scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
                canvas.drawCircle(cx + scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
            }

            // Mouth
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = scale * 0.035f
            paint.color = Color.rgb(160, 245, 255)
            val smile = RectF(cx - scale * 0.16f, bodyTop + scale * 0.46f,
                cx + scale * 0.16f, bodyTop + scale * 0.60f)
            canvas.drawArc(smile, 10f, 160f, false, paint)
            paint.style = Paint.Style.FILL

            // Arms
            paint.strokeWidth = scale * 0.11f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(110, 155, 175)
            val wave = dance || (System.currentTimeMillis() - lastTap < 700)
            canvas.drawLine(cx - scale * 0.62f, cy,
                cx - scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)
            canvas.drawLine(cx + scale * 0.62f, cy,
                cx + scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)

            // Feet
            canvas.drawRoundRect(cx - scale * 0.48f, bodyBottom - scale * 0.02f,
                cx - scale * 0.08f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)
            canvas.drawRoundRect(cx + scale * 0.08f, bodyBottom - scale * 0.02f,
                cx + scale * 0.48f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)

            // Label
            textPaint.textSize = scale * 0.18f
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("HOME BOT", cx, bodyBottom + scale * 0.55f, textPaint)
        }

        private fun drawBubble(canvas: Canvas, text: String, w: Float, h: Float) {
            paint.color = Color.argb(235, 245, 250, 252)
            val rect = RectF(w * 0.10f, h * 0.10f, w * 0.90f, h * 0.23f)
            canvas.drawRoundRect(rect, 35f, 35f, paint)
            textPaint.textSize = (w * 0.045f).coerceAtLeast(22f)
            textPaint.color = Color.rgb(20, 35, 45)
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(text, w / 2f, h * 0.18f, textPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN) {
                lastTap = System.currentTimeMillis()
                sleeping = false
                message = listOf(
                    "Hey! 👋",
                    "You found me!",
                    "Boop! 🤖",
                    "That tickles!",
                    "Ready for adventure?"
                ).random()
                messageUntil = lastTap + 2200
                targetX = (event.x / width).coerceIn(0.18f, 0.82f)
                targetY = (event.y / height).coerceIn(0.38f, 0.70f)
                invalidate()
                return true
            }
            return true
        }
    }
}
