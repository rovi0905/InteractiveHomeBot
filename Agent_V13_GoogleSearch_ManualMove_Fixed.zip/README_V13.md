# Agent V13

- Replaced key-free DuckDuckGo answers with direct Google Search in the default browser.
- No OpenAI API key or Google Search API key is embedded in the APK.
- Reduced floating overlay to 190dp x 235dp to minimize obstruction.
- Fixed manual dragging: the overlay window itself now follows finger movement, is clamped to the screen, and uses the stored WindowManager parameters.
- Tapping without dragging still opens the typing/search dialog.
- Keeps wrapped popup facts and user-started foreground overlay.
