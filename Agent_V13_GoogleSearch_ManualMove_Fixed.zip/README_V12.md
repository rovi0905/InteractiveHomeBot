# Agent V12

- Removed ChatGPT/OpenAI API-key integration.
- Added key-free DuckDuckGo web-answer search for typed questions.
- Compact floating overlay (230dp x 300dp) to reduce obstruction of other apps.
- Smaller Agent rendering and wrapped popup text.
- Overlay remains user-started and non-sticky.

Note: the web-answer service uses DuckDuckGo Instant Answer data; some questions may not have a direct answer.
