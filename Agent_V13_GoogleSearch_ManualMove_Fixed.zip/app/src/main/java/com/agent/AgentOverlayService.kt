package com.agent
import android.app.Dialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.WindowManager
import kotlin.math.*
import kotlin.random.Random

class AgentOverlayService : Service() {

    companion object {
        const val ACTION_COMMAND = "com.agent.COMMAND"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "agent_overlay"
        private const val NOTIFICATION_ID = 2101
    }

    private lateinit var windowManager: WindowManager
    private var agentView: FloatingAgentView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var destroyed = false

    private val spontaneous = arrayOf(
        "Space fact: a day on Venus is longer than its year. Cosmic scheduling is complicated.",
        "Space fact: Saturn would float in water if you had a bathtub big enough. Please don't try this.",
        "Joke: Why did the astronaut break up with the moon? It needed more space.",
        "Space fact: neutron stars can spin hundreds of times every second. That's one serious workout.",
        "Joke: I told a black hole a joke. It sucked.",
        "Space fact: there are more stars in the observable universe than grains of sand on many Earth beaches."
    )

    private val spontaneousRunnable = object : Runnable {
        override fun run() {
            if (!destroyed && agentView != null) {
                val item = spontaneous[Random.nextInt(spontaneous.size)]
                agentView?.showMessage(item)
            }
            handler.postDelayed(this, Random.nextLong(45_000L, 90_001L))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
        showOverlay()
        handler.postDelayed(spontaneousRunnable, Random.nextLong(30_000L, 60_001L))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra(EXTRA_COMMAND)
            ?: intent?.getStringExtra(EXTRA_TEXT)
        if (!command.isNullOrBlank()) {
            try {
                if (command.equals("typing", true)) startTypingInteraction()
                else agentView?.command(normalizeCommand(command))
            } catch (_: Exception) {
                // Never let a command crash the service.
            }
        }
        return START_NOT_STICKY
    }

    private fun normalizeCommand(raw: String): String = when {
        "dance" in raw.lowercase() -> "dance"
        "spin" in raw.lowercase() || "turn" in raw.lowercase() -> "spin"
        "jump" in raw.lowercase() -> "jump"
        "happy" in raw.lowercase() -> "happy"
        "sad" in raw.lowercase() -> "sad"
        "sleep" in raw.lowercase() -> "sleep"
        "wake" in raw.lowercase() || "awake" in raw.lowercase() -> "wake"
        "explore" in raw.lowercase() || "walk" in raw.lowercase() || "roam" in raw.lowercase() || "move" in raw.lowercase() -> "explore"
        "stop" in raw.lowercase() || "hide" in raw.lowercase() -> "hide"
        "hello" in raw.lowercase() || "hi" in raw.lowercase() || "hey" in raw.lowercase() -> "hello"
        else -> "hello"
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(): Notification {
        val launch = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Agent")
            .setContentText("Agent is floating and ready")
            .setOngoing(true)
            .setContentIntent(pending)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the floating Agent responsive."
                }
            )
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        agentView = FloatingAgentView(this)
        val overlayWidth = dp(190)
        val overlayHeight = dp(235)
        val params = WindowManager.LayoutParams(
            overlayWidth, overlayHeight,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(120)
        }
        try {
            overlayParams = params
            agentView?.visibility = View.VISIBLE
            windowManager.addView(agentView, params)
        } catch (_: SecurityException) {
            agentView = null
            overlayParams = null
            stopSelf()
        } catch (_: WindowManager.BadTokenException) {
            agentView = null
            overlayParams = null
            stopSelf()
        } catch (_: Exception) {
            agentView = null
            overlayParams = null
            stopSelf()
        }
    }

    fun startTypingInteraction() {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(12,20,38), Color.rgb(30,24,55))
            ).apply { cornerRadius = dp(24).toFloat() }
        }

        box.addView(TextView(this).apply {
            text = "✦  Agent"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(6))
        })

        box.addView(TextView(this).apply {
            text = "Search the web"
            textSize = 13f
            setTextColor(Color.rgb(150,225,255))
            setPadding(0, 0, 0, dp(8))
        })

        val input = EditText(this).apply {
            hint = "Ask Agent anything…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 16f
            minLines = 2
            maxLines = 5
            gravity = Gravity.TOP or Gravity.START
            setSingleLine(false)
            background = GradientDrawable().apply {
                setColor(Color.argb(90, 0, 0, 0))
                cornerRadius = dp(18).toFloat()
                setStroke(1, Color.argb(90, 110, 220, 255))
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(90)))

        val row = LinearLayout(this).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        val close = Button(this).apply {
            text = "Cancel"
            isAllCaps = false
            setOnClickListener { dialog.dismiss() }
        }
        val send = Button(this).apply {
            text = "Send"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(34,78,115), Color.rgb(73,51,132))
            ).apply { cornerRadius = dp(20).toFloat() }
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    dialog.dismiss()
                    handleUserText(value)
                }
            }
        }
        row.addView(close, LinearLayout.LayoutParams(dp(110), dp(52)))
        row.addView(send, LinearLayout.LayoutParams(dp(110), dp(52)).apply { leftMargin = dp(8) })
        box.addView(row)

        dialog.setContentView(box)
        dialog.window?.setType(
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
        )
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        dialog.setOnShowListener {
            input.requestFocus()
            input.postDelayed({
                (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }, 200)
        }
        dialog.show()
    }

    private fun handleUserText(text: String) {
        val local = normalizeCommandOrNull(text)
        if (local != null) {
            agentView?.command(local)
             if (local == "hello") agentView?.showMessage("Hello. What can I do for you?")
            return
        }
        agentView?.setState("thinking")
        agentView?.showMessage("Opening Google Search…")
        WebSearchClient.search(this, text) { answer ->
            if (destroyed) return@search
            agentView?.setState("typing")
            agentView?.showMessage(answer)
            handler.postDelayed({ agentView?.setState("idle") }, 1200)
        }
    }

    private fun normalizeCommandOrNull(raw: String): String? {
        val c = raw.lowercase()
        return when {
            "dance" in c -> "dance"
            "spin" in c || "turn around" in c -> "spin"
            "jump" in c -> "jump"
            "happy" in c -> "happy"
            "sad" in c -> "sad"
            "sleep" in c -> "sleep"
            "wake" in c || "awake" in c -> "wake"
            "explore" in c || "walk around" in c || "roam" in c -> "explore"
            "hide" in c || "go away" in c -> "hide"
            "hello" in c || "hi " in c || c == "hey" -> "hello"
            else -> null
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        agentView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        agentView = null
        overlayParams = null

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FloatingAgentView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans", Typeface.BOLD) }
        private var phase = 0f
        private var state = "idle"
        private var message = ""
        private var messageUntil = 0L
        private var sleeping = false
        private var specialState = ""
        private var specialUntil = 0L
        private var lastTap = 0L
        private var targetX = .50f; private var targetY = .65f
        private var agentX = .50f; private var agentY = .65f
        private var lastMove = 0L
        private var downRawX = 0f; private var downRawY = 0f; private var moved = false

        init { setLayerType(View.LAYER_TYPE_HARDWARE, null); isClickable = true; chooseTarget() }

        fun setState(s: String) { state = s; invalidate() }
        fun showMessage(t: String) { message = t; messageUntil = System.currentTimeMillis() + 5200; invalidate() }

        fun command(action: String) {
            val now = System.currentTimeMillis()
            sleeping = false
            when (action) {
                "dance" -> { specialState="dance"; specialUntil=now+4000; message="Let's dance! ✨" }
                "spin" -> { specialState="spin"; specialUntil=now+1800; message="Spin mode!" }
                "jump" -> { specialState="jump"; specialUntil=now+1600; message="Boing! 🚀" }
                "happy" -> { specialState="happy"; specialUntil=now+2600; message="I'm happy! ✦" }
                "sad" -> { specialState="sad"; specialUntil=now+2600; message="A little sad…" }
                "sleep" -> { sleeping=true; specialState=""; specialUntil=0; message="Zzz…" }
                "wake" -> { message="I'm awake! ✨" }
                "explore" -> { chooseTarget(); message="Exploring… 👀" }
                "hide" -> { (context as? AgentOverlayService)?.stopSelf(); return }
                else -> message="Hello! ✨"
            }
            state="idle"; messageUntil=now+3000; invalidate()
        }

        private fun chooseTarget() {
            targetX=Random.nextFloat().coerceIn(.25f,.75f)
            targetY=Random.nextFloat().coerceIn(.48f,.82f)
            lastMove=System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            val w=width.toFloat(); val h=height.toFloat()
            phase += .055f
            val now=System.currentTimeMillis()
            if (!sleeping) {
                val dx=targetX-agentX; val dy=targetY-agentY
                val d=sqrt(dx*dx+dy*dy)
                if(d>.008f){agentX+=dx*.010f; agentY+=dy*.010f}
                else if(now-lastMove>1800) chooseTarget()
            }
            val pulse = 1f + sin(phase*2f)*.025f
            val bob = if(sleeping) 0f else sin(phase*2f)*.012f
            val danceX = if(specialState=="dance" && now<specialUntil) cos(phase*5f)*.035f else 0f
            val cx=(agentX+danceX)*w; val cy=(agentY+bob)*h
            drawAgent(canvas,cx,cy,w,h,pulse)
            if(now<messageUntil) drawBubble(canvas,message,w,h)
            postInvalidateOnAnimation()
        }

        private fun drawAgent(c:Canvas,cx:Float,cy:Float,w:Float,h:Float,pulse:Float) {
            val now=System.currentTimeMillis()
            val thinking=state=="thinking"
            val typing=state=="typing"
            val scale=(w.coerceAtMost(h)*.27f).coerceIn(42f,64f)*pulse
            c.save()
            if(specialState=="spin" && now<specialUntil) c.rotate(sin(phase*8f)*18f,cx,cy)
            // premium glow
            paint.style=Paint.Style.FILL
            paint.shader=RadialGradient(cx,cy,scale*1.45f,intArrayOf(Color.argb(70,70,210,255),Color.argb(25,110,80,255),Color.TRANSPARENT),floatArrayOf(0f,.55f,1f),Shader.TileMode.CLAMP)
            c.drawCircle(cx,cy,scale*1.45f,paint); paint.shader=null
            // shadow
            paint.color=Color.argb(85,0,0,0)
            c.drawOval(cx-scale*.70f,cy+scale*.70f,cx+scale*.70f,cy+scale*.90f,paint)
            // antenna
            paint.strokeWidth=scale*.055f; paint.strokeCap=Paint.Cap.ROUND; paint.color=Color.rgb(185,225,245)
            c.drawLine(cx,cy-scale*.60f,cx,cy-scale*.95f,paint)
            paint.color=Color.rgb(100,235,255); c.drawCircle(cx,cy-scale*.99f,scale*.095f,paint)
            // body shell
            paint.shader=LinearGradient(cx-scale,cy-scale,cx+scale,cy+scale,Color.rgb(245,250,255),Color.rgb(95,135,170),Shader.TileMode.CLAMP)
            c.drawRoundRect(cx-scale*.72f,cy-scale*.58f,cx+scale*.72f,cy+scale*.58f,scale*.22f,scale*.22f,paint)
            paint.shader=null
            // visor
            paint.color=Color.rgb(7,17,29)
            c.drawRoundRect(cx-scale*.58f,cy-scale*.37f,cx+scale*.58f,cy+scale*.24f,scale*.16f,scale*.16f,paint)
            paint.style=Paint.Style.STROKE; paint.strokeWidth=scale*.035f
            paint.color=Color.argb(190,100,235,255)
            c.drawRoundRect(cx-scale*.58f,cy-scale*.37f,cx+scale*.58f,cy+scale*.24f,scale*.16f,scale*.16f,paint)
            paint.style=Paint.Style.FILL
            // eyes
            val eyeGlow=Color.rgb(100,240,255)
            paint.color=eyeGlow
            val eyeR=scale*.075f
            c.drawCircle(cx-scale*.23f,cy-scale*.08f,eyeR,paint); c.drawCircle(cx+scale*.23f,cy-scale*.08f,eyeR,paint)
            // state ring
            if(thinking || typing){
                paint.style=Paint.Style.STROKE
                paint.strokeWidth=scale*.045f
                paint.color=Color.rgb(130,110,255)
                val r=scale*(.78f+sin(phase*3f)*.04f)
                c.drawArc(cx-r,cy-r,cx+r,cy+r,phase*50f,240f,false,paint)
                paint.style=Paint.Style.FILL
            }
            // arms
            paint.strokeWidth=scale*.11f; paint.color=Color.rgb(125,165,195)
            val wave=now-lastTap<700 || specialState=="dance"
            c.drawLine(cx-scale*.72f,cy,cx-scale*(if(wave).98f else .86f),cy+scale*(if(wave)-.38f else .18f),paint)
            c.drawLine(cx+scale*.72f,cy,cx+scale*(if(wave).98f else .86f),cy+scale*(if(wave)-.38f else .18f),paint)
            // heart/status core
            paint.color=Color.rgb(90,210,255)
            c.drawCircle(cx,cy+scale*.40f,scale*.08f,paint)
            textPaint.textSize=scale*.17f; textPaint.color=Color.WHITE; textPaint.textAlign=Paint.Align.CENTER
            c.drawText("AGENT",cx,cy+scale*.72f,textPaint)
            if(thinking){
                textPaint.textSize=scale*.22f
                val dots=(now/350)%4
                c.drawText("•".repeat(dots.toInt()+1),cx,cy-scale*1.18f,textPaint)
            }
            c.restore()
        }

        private fun drawBubble(c:Canvas,text:String,w:Float,h:Float){
            // Wrapped, density-correct popup. textSize is in pixels, so use scaledDensity
            // rather than raw dp; this prevents oversized/clipped text on high-density phones.
            val bubbleLeft = dpForBubble(10f)
            val bubbleRight = w - dpForBubble(10f)
            val bubbleTop = dpForBubble(8f)
            val textPadding = dpForBubble(12f)
            val textWidth = (bubbleRight - bubbleLeft - textPadding * 2f).toInt().coerceAtLeast(1)

            val bubbleTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                typeface = Typeface.create("sans", Typeface.BOLD)
                textSize = 15f * resources.displayMetrics.scaledDensity
                color = Color.rgb(15,30,45)
                textAlign = Paint.Align.LEFT
            }

            // Keep facts concise enough to remain comfortably readable, while StaticLayout
            // performs real word wrapping instead of allowing text to run outside the bubble.
            val displayText = if (text.length > 120) text.take(117).trimEnd() + "…" else text

            val layout = StaticLayout.Builder.obtain(
                displayText, 0, displayText.length, bubbleTextPaint, textWidth
            )
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(true)
                .setLineSpacing(0f, 1.05f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NORMAL)
                .build()

            val availableHeight = h * .42f
            val bubbleHeight = (layout.height + textPadding * 2f)
                .coerceAtMost(availableHeight)

            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(
                0f, bubbleTop, 0f, bubbleTop + bubbleHeight,
                Color.argb(250,255,255,255),
                Color.argb(240,225,240,250),
                Shader.TileMode.CLAMP
            )
            val rect = RectF(
                bubbleLeft, bubbleTop,
                bubbleRight, bubbleTop + bubbleHeight
            )
            c.drawRoundRect(rect, dpForBubble(20f), dpForBubble(20f), paint)
            paint.shader = null

            c.save()
            c.clipRect(
                bubbleLeft + 1f, bubbleTop + 1f,
                bubbleRight - 1f, bubbleTop + bubbleHeight - 1f
            )
            val tx = bubbleLeft + textPadding
            val ty = bubbleTop + ((bubbleHeight - layout.height) / 2f).coerceAtLeast(textPadding)
            c.translate(tx, ty)
            layout.draw(c)
            c.restore()
        }

        private fun dpForBubble(v:Float):Float = v * resources.displayMetrics.density

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val service = context as AgentOverlayService
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = e.rawX
                    downRawY = e.rawY
                    moved = false
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRawX
                    val dy = e.rawY - downRawY
                    if (!moved && hypot(dx.toDouble(), dy.toDouble()) > dp(10)) moved = true
                    if (moved) {
                        val p = service.overlayParams ?: return true
                        val metrics = resources.displayMetrics
                        val maxX = (metrics.widthPixels - width).coerceAtLeast(0)
                        val maxY = (metrics.heightPixels - height).coerceAtLeast(0)
                        p.x = (p.x + dx).toInt().coerceIn(0, maxX)
                        p.y = (p.y + dy).toInt().coerceIn(0, maxY)
                        downRawX = e.rawX
                        downRawY = e.rawY
                        try { service.windowManager.updateViewLayout(this, p) } catch (_: Exception) {}
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    parent?.requestDisallowInterceptTouchEvent(false)
                    if (!moved && e.actionMasked == MotionEvent.ACTION_UP) {
                        lastTap = System.currentTimeMillis()
                        state = "typing"
                        showMessage("Type to Agent…")
                        service.startTypingInteraction()
                    }
                    return true
                }
            }
            return true
        }

        private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    }
}
