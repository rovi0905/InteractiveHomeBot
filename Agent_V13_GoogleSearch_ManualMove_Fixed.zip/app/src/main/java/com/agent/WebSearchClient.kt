package com.agent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/** Opens the user's default browser directly to Google Search.
 * No OpenAI or search API key is stored in the APK.
 */
object WebSearchClient {
    fun search(context: Context, question: String, callback: (String) -> Unit) {
        val q = question.trim()
        if (q.isBlank()) return
        val encoded = URLEncoder.encode(q, StandardCharsets.UTF_8.name())
        val uri = Uri.parse("https://www.google.com/search?q=$encoded")
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            callback("Google Search opened for:\n$q")
        } catch (_: Exception) {
            Toast.makeText(context, "Could not open Google Search.", Toast.LENGTH_SHORT).show()
            callback("I couldn't open Google Search. Please check that a browser is installed.")
        }
    }
}
