package com.agent

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var statusText: TextView

    private fun bg() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(7,12,25), Color.rgb(18,22,48), Color.rgb(7,13,27))
    ).apply { cornerRadius = 42f }

    private fun cardBg() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(235,28,38,62), Color.argb(220,15,24,45))
    ).apply { cornerRadius = 30f; setStroke(1, Color.argb(90,110,220,255)) }

    private fun actionButton(text: String, onClick: () -> Unit) =
        Button(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(34,78,115), Color.rgb(73,51,132))
            ).apply { cornerRadius = 24f }
            setPadding(24, 8, 24, 8)
            setOnClickListener { onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7,12,25)
        window.navigationBarColor = Color.rgb(7,12,25)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) updateStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 26, 28, 24)
            background = bg()
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7,12,25)) }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "✦  AGENT"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 2)
        })
        root.addView(TextView(this).apply {
            text = "Your floating web companion"
            textSize = 16f
            setTextColor(Color.rgb(130,225,255))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        })

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 18, 22, 18)
        }
        statusText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        statusCard.addView(statusText)
        root.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,14) })

        val launchCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 20, 22, 20)
        }
        launchCard.addView(TextView(this).apply {
            text = "FLOATING AGENT"
            textSize = 13f
            setTextColor(Color.rgb(110,235,255))
        })
        launchCard.addView(TextView(this).apply {
            text = "Tap Agent to open chat."
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 4)
        })
        launchCard.addView(TextView(this).apply {
            text = "Agent moves around your home screen and periodically shows interesting facts. Tap it anytime to search the web."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 14)
        })
        launchCard.addView(actionButton("✦  Start / Show Agent") { startAgent() },
            LinearLayout.LayoutParams(-1, 54))
        root.addView(launchCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,14) })

        val webCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22, 20, 22, 20)
        }
        webCard.addView(TextView(this).apply {
            text = "WEB SEARCH"
            textSize = 13f
            setTextColor(Color.rgb(110,235,255))
        })
        webCard.addView(TextView(this).apply {
            text = "Answers from the web"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0,8,0,4)
        })
        webCard.addView(TextView(this).apply {
            text = "Agent searches the web for typed questions. No OpenAI API key is required."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        root.addView(webCard, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,14) })

        val facts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(22,20,22,20)
        }
        facts.addView(TextView(this).apply {
            text="POPUP FACTS"
            textSize=13f; setTextColor(Color.rgb(110,235,255))
        })
        facts.addView(TextView(this).apply {
            text="Curious by default"
            textSize=18f; setTextColor(Color.WHITE)
            typeface=android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0,8,0,4)
        })
        facts.addView(TextView(this).apply {
            text="Agent will occasionally show a small fact or thought popup. Tapping Agent opens the typing chat instead of voice input."
            textSize=14f; setTextColor(Color.LTGRAY)
        })
        root.addView(facts, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,20) })

        root.addView(TextView(this).apply {
            text="Agent • Web search powered"
            textSize=12f; setTextColor(Color.rgb(105,125,150)); gravity=Gravity.CENTER
            setPadding(0,8,0,12)
        })

        setContentView(scroll)
        updateStatus()
    }

    private fun updateStatus() {
        statusText.text = if (Settings.canDrawOverlays(this))
            "●  Floating permission ON   •   Typing chat ready"
        else
            "○  Allow “Appear on top” to place Agent over your home screen"
    }

    private fun startAgent() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, AgentOverlayService::class.java))
        Toast.makeText(this, "Agent is floating. Tap Agent to type.", Toast.LENGTH_SHORT).show()
    }
}
