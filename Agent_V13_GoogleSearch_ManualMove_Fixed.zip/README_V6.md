# Agent V11 — Stable Floating Build

V11 is a stability-first revision of Agent. The floating service:
- starts only when the user taps Start / Show Agent
- is NOT sticky and does not automatically restart after being stopped
- uses a single application-overlay window
- does not request microphone foreground-service mode
- catches overlay/service startup failures instead of crashing
- keeps typed ChatGPT interaction

If the overlay cannot start, the service stops cleanly rather than retrying.
