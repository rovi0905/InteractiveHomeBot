package com.interactivehomebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class BotOverlayService : Service() {

    companion object {
        const val ACTION_COMMAND = "com.interactivehomebot.COMMAND"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL_ID = "interactive_home_bot"
        private const val NOTIFICATION_ID = 2001
    }

    private lateinit var windowManager: WindowManager
    private var botView: FloatingBotView? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra(EXTRA_COMMAND)
            ?: intent?.getStringExtra(EXTRA_TEXT)
            ?: intent?.data?.getQueryParameter(EXTRA_COMMAND)

        if (!command.isNullOrBlank()) {
            botView?.command(normalizeCommand(command))
        }

        return START_STICKY
    }

    private fun normalizeCommand(raw: String): String {
        val c = raw.lowercase()
        return when {
            "dance" in c -> "dance"
            "sleep" in c -> "sleep"
            "wake" in c -> "wake"
            "explore" in c || "walk" in c -> "explore"
            "stop" in c || "hide" in c -> "hide"
            "hello" in c || "hi" in c -> "hello"
            else -> "hello"
        }
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Interactive Home Bot")
            .setContentText("Your floating bot is active")
            .setOngoing(true)
            .setContentIntent(pending)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Interactive Home Bot",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating home bot responsive."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        botView = FloatingBotView(this)

        val size = dp(190)
        val params = WindowManager.LayoutParams(
            size,
            size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24)
            y = dp(190)
        }

        try {
            windowManager.addView(botView, params)
        } catch (_: Exception) {
            botView = null
            stopSelf()
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        botView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        botView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FloatingBotView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans", Typeface.BOLD)
        }

        private var phase = 0f
        private var state = "idle"
        private var message = "Hi! Tap me 👋"
        private var messageUntil = 0L
        private var sleeping = false
        private var danceUntil = 0L
        private var lastTap = 0L
        private var targetX = 0.50f
        private var targetY = 0.55f
        private var botX = 0.50f
        private var botY = 0.55f
        private var lastMove = 0L
        private var downRawX = 0f
        private var downRawY = 0f
        private var moved = false

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            chooseTarget()
        }

        fun command(action: String) {
            val now = System.currentTimeMillis()
            when (action) {
                "dance" -> {
                    sleeping = false
                    danceUntil = now + 4000
                    message = "Let's dance! 🎵"
                }
                "sleep" -> {
                    sleeping = true
                    danceUntil = 0L
                    message = "Zzz... 😴"
                }
                "wake" -> {
                    sleeping = false
                    message = "I'm awake! ✨"
                }
                "explore" -> {
                    sleeping = false
                    chooseTarget()
                    message = "Exploring! 👀"
                }
                "hide" -> {
                    (context as? BotOverlayService)?.stopSelf()
                    return
                }
                else -> {
                    sleeping = false
                    message = "Hello! 🤖"
                }
            }
            messageUntil = now + 2600
            invalidate()
        }

        private fun chooseTarget() {
            targetX = Random.nextFloat().coerceIn(0.22f, 0.78f)
            targetY = Random.nextFloat().coerceIn(0.34f, 0.72f)
            lastMove = System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            phase += 0.055f

            if (!sleeping) {
                val dx = targetX - botX
                val dy = targetY - botY
                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                if (distance > 0.008f) {
                    botX += dx * 0.012f
                    botY += dy * 0.012f
                } else if (System.currentTimeMillis() - lastMove > 2200) {
                    chooseTarget()
                }
            }

            val now = System.currentTimeMillis()
            val dance = now < danceUntil
            val bob = if (sleeping) 0f else sin(phase * 2f) * 0.012f
            val danceX = if (dance) cos(phase * 5f) * 0.035f else 0f
            val cx = (botX + danceX) * w
            val cy = (botY + bob) * h

            drawBot(canvas, cx, cy, w, h, dance)

            if (now < messageUntil) {
                drawBubble(canvas, message, w, h)
            }

            postInvalidateOnAnimation()
        }

        private fun drawBot(canvas: Canvas, cx: Float, cy: Float, w: Float, h: Float, dance: Boolean) {
            val scale = (w.coerceAtMost(h) * 0.30f).coerceIn(48f, 78f)
            val bodyTop = cy - scale * 0.55f
            val bodyBottom = cy + scale * 0.55f

            paint.color = Color.argb(90, 0, 0, 0)
            canvas.drawOval(
                cx - scale * 0.62f, bodyBottom + scale * 0.25f,
                cx + scale * 0.62f, bodyBottom + scale * 0.48f, paint
            )

            paint.strokeWidth = scale * 0.055f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(180, 220, 235)
            canvas.drawLine(cx, bodyTop, cx, bodyTop - scale * 0.35f, paint)
            paint.color = Color.rgb(90, 220, 255)
            canvas.drawCircle(cx, bodyTop - scale * 0.40f, scale * 0.09f, paint)

            paint.color = Color.rgb(80, 120, 145)
            canvas.drawRoundRect(
                cx - scale * 0.65f, bodyTop,
                cx + scale * 0.65f, bodyBottom,
                scale * 0.22f, scale * 0.22f, paint
            )

            paint.color = Color.rgb(12, 22, 30)
            canvas.drawRoundRect(
                cx - scale * 0.52f, bodyTop + scale * 0.16f,
                cx + scale * 0.52f, bodyTop + scale * 0.62f,
                scale * 0.15f, scale * 0.15f, paint
            )

            val blinking = ((System.currentTimeMillis() / 1000) % 5 == 0L)
            paint.color = Color.rgb(100, 235, 255)
            if (sleeping || blinking) {
                paint.strokeWidth = scale * 0.045f
                canvas.drawLine(cx - scale * 0.31f, bodyTop + scale * 0.39f, cx - scale * 0.12f, bodyTop + scale * 0.39f, paint)
                canvas.drawLine(cx + scale * 0.12f, bodyTop + scale * 0.39f, cx + scale * 0.31f, bodyTop + scale * 0.39f, paint)
            } else {
                canvas.drawCircle(cx - scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
                canvas.drawCircle(cx + scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
            }

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = scale * 0.035f
            paint.color = Color.rgb(160, 245, 255)
            val smile = RectF(
                cx - scale * 0.16f, bodyTop + scale * 0.46f,
                cx + scale * 0.16f, bodyTop + scale * 0.60f
            )
            canvas.drawArc(smile, 10f, 160f, false, paint)
            paint.style = Paint.Style.FILL

            paint.strokeWidth = scale * 0.11f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(110, 155, 175)
            val wave = dance || (System.currentTimeMillis() - lastTap < 700)
            canvas.drawLine(cx - scale * 0.62f, cy,
                cx - scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)
            canvas.drawLine(cx + scale * 0.62f, cy,
                cx + scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)

            canvas.drawRoundRect(cx - scale * 0.48f, bodyBottom - scale * 0.02f,
                cx - scale * 0.08f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)
            canvas.drawRoundRect(cx + scale * 0.08f, bodyBottom - scale * 0.02f,
                cx + scale * 0.48f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)

            textPaint.textSize = scale * 0.18f
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("HOME BOT", cx, bodyBottom + scale * 0.55f, textPaint)
        }

        private fun drawBubble(canvas: Canvas, text: String, w: Float, h: Float) {
            paint.color = Color.argb(235, 245, 250, 252)
            val rect = RectF(w * 0.03f, h * 0.02f, w * 0.97f, h * 0.22f)
            canvas.drawRoundRect(rect, 22f, 22f, paint)
            textPaint.textSize = (w * 0.075f).coerceAtLeast(13f)
            textPaint.color = Color.rgb(20, 35, 45)
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(text, w / 2f, h * 0.155f, textPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.rawX - downRawX) > 12 || kotlin.math.abs(event.rawY - downRawY) > 12) {
                        moved = true
                    }
                    if (moved) {
                        val service = context as BotOverlayService
                        val params = layoutParams as WindowManager.LayoutParams
                        params.x = (params.x + (event.rawX - downRawX)).toInt()
                        params.y = (params.y + (event.rawY - downRawY)).toInt()
                        downRawX = event.rawX
                        downRawY = event.rawY
                        service.windowManager.updateViewLayout(this, params)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val now = System.currentTimeMillis()
                        if (now - lastTap < 500) {
                            command("dance")
                        } else {
                            lastTap = now
                            sleeping = false
                            message = listOf("Hey! 👋", "Boop! 🤖", "You found me!", "Ready! ✨").random()
                            messageUntil = now + 2200
                            chooseTarget()
                            invalidate()
                        }
                    }
                    return true
                }
            }
            return true
        }
    }
}
