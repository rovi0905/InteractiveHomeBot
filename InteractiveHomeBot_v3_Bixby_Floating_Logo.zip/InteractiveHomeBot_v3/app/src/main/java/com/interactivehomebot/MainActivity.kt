package com.interactivehomebot

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.rgb(16, 24, 32))
        window.setNavigationBarColor(Color.rgb(16, 24, 32))

        val command = extractCommand(intent)

        if (Settings.canDrawOverlays(this)) {
            startBot(command)
            if (command != null) {
                finish()
                return
            }
        }

        showSetup(command)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val command = extractCommand(intent)
        if (Settings.canDrawOverlays(this)) {
            startBot(command)
            if (command != null) finish()
        }
    }

    private fun extractCommand(intent: Intent?): String? {
        return intent?.getStringExtra(BotOverlayService.EXTRA_COMMAND)
            ?: intent?.getStringExtra(BotOverlayService.EXTRA_TEXT)
            ?: intent?.data?.getQueryParameter(BotOverlayService.EXTRA_COMMAND)
    }

    private fun startBot(command: String? = null) {
        val serviceIntent = Intent(this, BotOverlayService::class.java).apply {
            if (!command.isNullOrBlank()) {
                action = BotOverlayService.ACTION_COMMAND
                putExtra(BotOverlayService.EXTRA_COMMAND, command)
            }
        }
        startForegroundService(serviceIntent)
    }

    private fun showSetup(pendingCommand: String?) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 70, 48, 48)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }

        val title = TextView(this).apply {
            text = "🤖  Interactive Home Bot"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val info = TextView(this).apply {
            text = "Your bot can float over the Home screen and other apps, move around, react to taps, and receive commands from a Bixby-ready intent interface.\n\nFirst, allow 'Appear on top' so the bot can float."
            textSize = 17f
            setTextColor(Color.LTGRAY)
            setPadding(0, 40, 0, 35)
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        val overlayButton = Button(this).apply {
            text = "Allow floating bot"
            setOnClickListener {
                val uri = Uri.parse("package:$packageName")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri))
            }
        }
        root.addView(overlayButton, LinearLayout.LayoutParams(-1, -2))

        val startButton = Button(this).apply {
            text = "Start Home Bot"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startBot(pendingCommand)
                    finish()
                } else {
                    val uri = Uri.parse("package:$packageName")
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri))
                }
            }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, -2))

        val commandInfo = TextView(this).apply {
            text = "\nVoice/deep-link commands supported:\n• hello\n• dance\n• explore / walk\n• sleep\n• wake\n• hide\n\nExample deep link:\ninteractivehomebot://command?command=dance"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }
        root.addView(commandInfo, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }
}
