# Bixby integration

Interactive Home Bot exposes a Bixby-ready Android command entry point and a deep link:

`interactivehomebot://command?command=dance`

Supported commands:
- `hello`
- `dance`
- `explore`
- `walk`
- `sleep`
- `wake`
- `hide`

A Bixby capsule can launch the Android app using the app's deep-link intent. The app then starts the floating bot (after the user has granted the Android "Appear on top" permission) and executes the requested command.

## Important Bixby limitation

Samsung's Bixby developer documentation says Bixby actions can launch applications on the device, but Bixby does not continue interacting with the launched application. Therefore this project provides the app-side intent/deep-link interface needed for a Bixby capsule; a full Bixby Marketplace capsule still needs to be created/tested in Bixby Developer Studio or Samsung Automation Studio with the user's Samsung/Bixby developer account.

## Example intent URI

`interactivehomebot://command?command=hello`

`interactivehomebot://command?command=dance`

`interactivehomebot://command?command=explore`

The floating bot itself is implemented as an Android application overlay backed by a foreground service so it can remain visible while the user is on the Home screen or in another app.
