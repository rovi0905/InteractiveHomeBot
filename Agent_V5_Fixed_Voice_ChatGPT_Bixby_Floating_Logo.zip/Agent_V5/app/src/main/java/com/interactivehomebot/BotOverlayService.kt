package com.interactivehomebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class BotOverlayService : Service() {

    companion object {
        const val ACTION_COMMAND = "com.interactivehomebot.COMMAND"
        const val EXTRA_COMMAND = "command"
        const val EXTRA_TEXT = "text"
        const val ACTION_VOICE = "com.interactivehomebot.VOICE"
        private const val CHANNEL_ID = "interactive_home_bot"
        private const val NOTIFICATION_ID = 2001
    }

    private lateinit var windowManager: WindowManager
    private var botView: FloatingBotView? = null
    private var micView: MicOverlayView? = null
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundCompat()
        showOverlay()
        showMicButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent?.getStringExtra(EXTRA_COMMAND)
            ?: intent?.getStringExtra(EXTRA_TEXT)
            ?: intent?.data?.getQueryParameter(EXTRA_COMMAND)

        if (!command.isNullOrBlank()) {
            if (command == "voice") startVoiceInteraction() else botView?.command(normalizeCommand(command))
        }

        return START_STICKY
    }

    private fun normalizeCommand(raw: String): String {
        val c = raw.lowercase()
        return when {
            "dance" in c -> "dance"
            "spin" in c || "turn" in c -> "spin"
            "jump" in c -> "jump"
            "happy" in c -> "happy"
            "sad" in c -> "sad"
            "sleep" in c -> "sleep"
            "wake" in c || "awake" in c -> "wake"
            "explore" in c || "walk" in c || "roam" in c || "move" in c -> "explore"
            "stop" in c || "hide" in c -> "hide"
            "hello" in c || "hi" in c || "hey" in c -> "hello"
            else -> "hello"
        }
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Agent")
            .setContentText("Agent is floating and ready")
            .setOngoing(true)
            .setContentIntent(pending)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Agent",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating home bot responsive."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        botView = FloatingBotView(this)

        val size = dp(190)
        val params = WindowManager.LayoutParams(
            size,
            size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24)
            y = dp(190)
        }

        try {
            windowManager.addView(botView, params)
        } catch (_: Exception) {
            botView = null
            stopSelf()
        }
    }

    private fun showMicButton() {
        if (!Settings.canDrawOverlays(this) || micView != null) return
        micView = MicOverlayView(this).also { view ->
            val size = dp(62)
            val params = WindowManager.LayoutParams(size,size,if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=dp(210); y=dp(235) }
            try { windowManager.addView(view,params) } catch (_:Exception) { micView=null }
        }
    }

    private fun startVoiceInteraction() {
        botView?.showMessage("How can I help? 🎙️")
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            botView?.showMessage("Please allow microphone access in Agent.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { botView?.showMessage("No speech recognition service is available."); return }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { botView?.showMessage("I'm listening… 👂") }
            override fun onBeginningOfSpeech() { botView?.showMessage("Go ahead…") }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { botView?.showMessage("Thinking… 🤔") }
            override fun onError(error: Int) { botView?.showMessage(if(error==SpeechRecognizer.ERROR_NO_MATCH)"I didn't catch that." else "Voice input failed. Try again.") }
            override fun onResults(results: Bundle?) {
                val text=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if(text.isNullOrBlank()){botView?.showMessage("I didn't catch that.");return}
                val command=normalizeCommandOrNull(text)
                if(command!=null){botView?.command(command)} else {
                    botView?.showMessage("I'll ask ChatGPT… 💬")
                    ChatGPTClient.ask(this@BotOverlayService,text){answer -> botView?.showMessage(answer)}
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val ri=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,java.util.Locale.getDefault());putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);putExtra(RecognizerIntent.EXTRA_PROMPT,"How can I help?") }
        try { speechRecognizer?.startListening(ri) } catch (_:Exception) { botView?.showMessage("I couldn't start the microphone.") }
    }

    private fun normalizeCommandOrNull(raw:String):String? {
        val c=raw.lowercase()
        return when {
            "dance" in c -> "dance"; "spin" in c || "turn" in c -> "spin"; "jump" in c -> "jump"; "happy" in c -> "happy"; "sad" in c -> "sad"; "sleep" in c -> "sleep"; "wake" in c || "awake" in c -> "wake"; "explore" in c || "walk" in c || "roam" in c || "move" in c -> "explore"; "stop" in c || "hide" in c -> "hide"; "hello" in c || "hi" in c || "hey" in c -> "hello"; else -> null
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        botView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        botView = null
        micView?.let { try { windowManager.removeView(it) } catch (_:Exception) {} }
        micView=null
        speechRecognizer?.destroy()
        speechRecognizer=null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class FloatingBotView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans", Typeface.BOLD)
        }

        private var phase = 0f
        private var state = "idle"
        private var message = "Hi! Tap me 👋"
        private var messageUntil = 0L
        private var sleeping = false
        private var danceUntil = 0L
        private var specialUntil = 0L
        private var specialState = ""
        private var lastTap = 0L
        private var targetX = 0.50f
        private var targetY = 0.55f
        private var botX = 0.50f
        private var botY = 0.55f
        private var lastMove = 0L
        private var downRawX = 0f
        private var downRawY = 0f
        private var moved = false

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            chooseTarget()
        }

        fun showMessage(text:String){ message=text; messageUntil=System.currentTimeMillis()+4500; invalidate() }

        fun command(action: String) {
            val now = System.currentTimeMillis()
            when (action) {
                "dance" -> {
                    sleeping = false
                    danceUntil = now + 4000
                    specialState = "dance"
                    specialUntil = now + 4000
                    message = "Let's dance! 🎵"
                }
                "spin" -> {
                    sleeping = false
                    specialState = "spin"
                    specialUntil = now + 1800
                    message = "Spin mode! 🌀"
                }
                "jump" -> {
                    sleeping = false
                    specialState = "jump"
                    specialUntil = now + 1600
                    message = "Boing! 🚀"
                }
                "happy" -> {
                    sleeping = false
                    specialState = "happy"
                    specialUntil = now + 2600
                    message = "I'm happy! ✨"
                }
                "sad" -> {
                    sleeping = false
                    specialState = "sad"
                    specialUntil = now + 2600
                    message = "A little sad… 💙"
                }
                "sleep" -> {
                    sleeping = true
                    danceUntil = 0L
                    specialUntil = 0L
                    specialState = ""
                    message = "Zzz... 😴"
                }
                "wake" -> {
                    sleeping = false
                    specialUntil = 0L
                    specialState = ""
                    message = "I'm awake! ✨"
                }
                "explore" -> {
                    sleeping = false
                    chooseTarget()
                    specialState = ""
                    specialUntil = 0L
                    message = "Exploring! 👀"
                }
                "hide" -> {
                    (context as? BotOverlayService)?.stopSelf()
                    return
                }
                else -> {
                    sleeping = false
                    message = "Hello! 🤖"
                }
            }
            messageUntil = now + 2600
            invalidate()
        }

        private fun chooseTarget() {
            targetX = Random.nextFloat().coerceIn(0.22f, 0.78f)
            targetY = Random.nextFloat().coerceIn(0.34f, 0.72f)
            lastMove = System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            phase += 0.055f

            if (!sleeping) {
                val dx = targetX - botX
                val dy = targetY - botY
                val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                if (distance > 0.008f) {
                    botX += dx * 0.012f
                    botY += dy * 0.012f
                } else if (System.currentTimeMillis() - lastMove > 2200) {
                    chooseTarget()
                }
            }

            val now = System.currentTimeMillis()
            val dance = now < danceUntil
            val special = now < specialUntil
            if (!special && specialState.isNotEmpty()) specialState = ""
            val bob = when {
                sleeping -> 0f
                specialState == "jump" && special -> -kotlin.math.abs(sin(phase * 4f)) * 0.12f
                else -> sin(phase * 2f) * 0.012f
            }
            val danceX = if (dance) cos(phase * 5f) * 0.035f else 0f
            val cx = (botX + danceX) * w
            val cy = (botY + bob) * h

            drawBot(canvas, cx, cy, w, h, dance)

            if (now < messageUntil) {
                drawBubble(canvas, message, w, h)
            }

            postInvalidateOnAnimation()
        }

        private fun drawBot(canvas: Canvas, cx: Float, cy: Float, w: Float, h: Float, dance: Boolean) {
            val rotating = specialState == "spin" && System.currentTimeMillis() < specialUntil
            val tilt = if (rotating) sin(phase * 8f) * 18f else 0f
            canvas.save()
            canvas.rotate(tilt, cx, cy)
            val scale = (w.coerceAtMost(h) * 0.30f).coerceIn(48f, 78f)
            val bodyTop = cy - scale * 0.55f
            val bodyBottom = cy + scale * 0.55f

            paint.color = Color.argb(90, 0, 0, 0)
            canvas.drawOval(
                cx - scale * 0.62f, bodyBottom + scale * 0.25f,
                cx + scale * 0.62f, bodyBottom + scale * 0.48f, paint
            )

            paint.strokeWidth = scale * 0.055f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(180, 220, 235)
            canvas.drawLine(cx, bodyTop, cx, bodyTop - scale * 0.35f, paint)
            paint.color = Color.rgb(90, 220, 255)
            canvas.drawCircle(cx, bodyTop - scale * 0.40f, scale * 0.09f, paint)

            paint.color = Color.rgb(80, 120, 145)
            canvas.drawRoundRect(
                cx - scale * 0.65f, bodyTop,
                cx + scale * 0.65f, bodyBottom,
                scale * 0.22f, scale * 0.22f, paint
            )

            paint.color = Color.rgb(12, 22, 30)
            canvas.drawRoundRect(
                cx - scale * 0.52f, bodyTop + scale * 0.16f,
                cx + scale * 0.52f, bodyTop + scale * 0.62f,
                scale * 0.15f, scale * 0.15f, paint
            )

            val blinking = ((System.currentTimeMillis() / 1000) % 5 == 0L)
            paint.color = Color.rgb(100, 235, 255)
            if (sleeping || blinking) {
                paint.strokeWidth = scale * 0.045f
                canvas.drawLine(cx - scale * 0.31f, bodyTop + scale * 0.39f, cx - scale * 0.12f, bodyTop + scale * 0.39f, paint)
                canvas.drawLine(cx + scale * 0.12f, bodyTop + scale * 0.39f, cx + scale * 0.31f, bodyTop + scale * 0.39f, paint)
            } else {
                canvas.drawCircle(cx - scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
                canvas.drawCircle(cx + scale * 0.22f, bodyTop + scale * 0.39f, scale * 0.075f, paint)
            }

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = scale * 0.035f
            paint.color = Color.rgb(160, 245, 255)
            val smile = RectF(
                cx - scale * 0.16f, bodyTop + scale * 0.46f,
                cx + scale * 0.16f, bodyTop + scale * 0.60f
            )
            canvas.drawArc(smile, 10f, 160f, false, paint)
            paint.style = Paint.Style.FILL

            paint.strokeWidth = scale * 0.11f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(110, 155, 175)
            val wave = dance || (System.currentTimeMillis() - lastTap < 700)
            canvas.drawLine(cx - scale * 0.62f, cy,
                cx - scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)
            canvas.drawLine(cx + scale * 0.62f, cy,
                cx + scale * (if (wave) 0.92f else 0.78f),
                cy + scale * (if (wave) -0.42f else 0.18f), paint)

            canvas.drawRoundRect(cx - scale * 0.48f, bodyBottom - scale * 0.02f,
                cx - scale * 0.08f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)
            canvas.drawRoundRect(cx + scale * 0.08f, bodyBottom - scale * 0.02f,
                cx + scale * 0.48f, bodyBottom + scale * 0.18f, scale * 0.1f, scale * 0.1f, paint)

            textPaint.textSize = scale * 0.18f
            textPaint.color = Color.WHITE
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("AGENT", cx, bodyBottom + scale * 0.55f, textPaint)

            if (specialState == "happy" && System.currentTimeMillis() < specialUntil) {
                textPaint.textSize = scale * 0.28f
                canvas.drawText("✦", cx - scale * 0.75f, bodyTop + scale * 0.05f, textPaint)
                canvas.drawText("✦", cx + scale * 0.75f, bodyTop + scale * 0.05f, textPaint)
            }
            canvas.restore()
        }

        private fun drawBubble(canvas: Canvas, text: String, w: Float, h: Float) {
            paint.color = Color.argb(235, 245, 250, 252)
            val rect = RectF(w * 0.03f, h * 0.02f, w * 0.97f, h * 0.22f)
            canvas.drawRoundRect(rect, 22f, 22f, paint)
            textPaint.textSize = (w * 0.075f).coerceAtLeast(13f)
            textPaint.color = Color.rgb(20, 35, 45)
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(text, w / 2f, h * 0.155f, textPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.rawX - downRawX) > 12 || kotlin.math.abs(event.rawY - downRawY) > 12) {
                        moved = true
                    }
                    if (moved) {
                        val service = context as BotOverlayService
                        val params = layoutParams as WindowManager.LayoutParams
                        params.x = (params.x + (event.rawX - downRawX)).toInt()
                        params.y = (params.y + (event.rawY - downRawY)).toInt()
                        downRawX = event.rawX
                        downRawY = event.rawY
                        service.windowManager.updateViewLayout(this, params)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val now = System.currentTimeMillis()
                        lastTap = now
                        sleeping = false
                        showMessage("How can I help? 🎙️")
                        (context as BotOverlayService).startVoiceInteraction()
                    }
                    return true
                }
            }
            return true
        }
    }
    private class MicOverlayView(context: Context) : View(context) {
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        init { setLayerType(View.LAYER_TYPE_SOFTWARE,null) }
        override fun onDraw(c:Canvas){
            val w=width.toFloat();val h=height.toFloat();paint.color=Color.argb(235,20,30,42);c.drawCircle(w/2,h/2,w*0.44f,paint);paint.color=Color.rgb(110,235,255);paint.style=Paint.Style.STROKE;paint.strokeWidth=w*0.08f;c.drawRoundRect(w*.39f,h*.22f,w*.61f,h*.62f,w*.11f,w*.11f,paint);c.drawArc(w*.27f,h*.40f,w*.73f,h*.78f,0f,180f,false,paint);c.drawLine(w*.5f,h*.78f,w*.5f,h*.88f,paint);c.drawLine(w*.38f,h*.88f,w*.62f,h*.88f,paint);paint.style=Paint.Style.FILL
        }
        override fun onTouchEvent(e:MotionEvent):Boolean{if(e.actionMasked==MotionEvent.ACTION_UP){(context as BotOverlayService).startVoiceInteraction();return true};return true}
    }

}
