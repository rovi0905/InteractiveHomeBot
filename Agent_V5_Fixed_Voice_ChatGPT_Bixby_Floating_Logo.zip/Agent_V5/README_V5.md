# Agent V5 — Floating Voice + ChatGPT + Bixby-ready

Agent is the V5 evolution of the floating Android bot.

## New V5 behavior
- The floating bot is named **Agent** everywhere in the user-facing UI.
- A microphone button is visible beside the floating Agent.
- Tapping Agent starts voice interaction and Agent asks: **“How can I help?”**
- Speaking a supported bot command (dance, spin, jump, happy, sad, sleep, wake, explore, hide, hello) triggers the animation.
- Other spoken questions are sent to the OpenAI Responses API and the answer appears in Agent's speech bubble.
- The microphone service is user-initiated and declared as a microphone foreground-service type. Android imposes while-in-use microphone restrictions, so Agent should be started from the app before using the floating microphone. See Android documentation.

## ChatGPT/OpenAI setup
1. Install Agent.
2. Open Agent and grant **Appear on top** and **Microphone** permissions.
3. Paste your own OpenAI API key into the ChatGPT/OpenAI connection field and save it.
4. Start Agent.
5. Tap the floating Agent or the floating microphone button.
6. When Agent says **How can I help?**, ask a question.

The APK does **not** contain a shared API key. The key is stored locally in the app's private SharedPreferences. For a production/public app, replace the direct API call with a secure backend so the secret key is never exposed to the APK.

## OpenAI connection
`ChatGPTClient.kt` contains the Responses API integration. Default model is `gpt-5-mini`; the model is editable in the app UI.

Endpoint:
`https://api.openai.com/v1/responses`

## Bixby
The existing `interactivehomebot://command?command=dance` deep link remains available for Bixby/automation integrations. This is a Bixby-ready Android command entry point; a full Bixby capsule still requires its separate Samsung/Bixby configuration.


Build fix: corrected the overlay service declaration syntax and matched the manifest theme to Theme.Agent. Version code 6.
